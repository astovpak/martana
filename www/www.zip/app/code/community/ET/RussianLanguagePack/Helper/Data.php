<?php
/**
 * NOTICE OF LICENSE
 *
 * You may not sell, sub-license, rent or lease
 * any portion of the Software or Documentation to anyone.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade to newer
 * versions in the future.
 *
 * @category   ET
 * @package    ET_RussianLanguagePack
 * @copyright  Copyright (c) 2012 ET Web Solutions (http://etwebsolutions.com)
 * @contacts   support@etwebsolutions.com
 * @license    http://shop.etwebsolutions.com/etws-license-free-v1/   ETWS Free License (EFL1)
 */

class ET_RussianLanguagePack_Helper_Data extends Mage_Core_Helper_Abstract
{
    /**
     * @return boolean
     */
    public function isEditorTranslationEnabled()
    {
        return Mage::getStoreConfig('etrussianlanguagepack/general/translate_editor');
    }
}